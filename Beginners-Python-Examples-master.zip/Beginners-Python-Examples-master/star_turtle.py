Python 3.7.1 (v3.7.1:260ec2c36a, Oct 20 2018, 14:05:16) [MSC v.1915 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import turtle
>>> star=turtle.Turtle()
>>> win=turtle.Screen()
>>> win.setworldcoordinates(-100,-100,100,100)
>>> for i in range(5):
	star.forward(50)
	star.right(144)

	
>>> 
