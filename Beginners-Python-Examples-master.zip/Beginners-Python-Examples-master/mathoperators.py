# maths sucks make it cool with python
# math operators

# INTEGERS
# integers are whole numbers positive or negative
# + operator adds numbers
add = 24 + 1004
# - operator subtracts second number from First
subtract = 546 - 132
# * multiplies numbers
multiply = 90 * 4
# / divides numbers
divide = 36/6
# returns the remainder of the division
modulo = 17 % 3

# FLOAT
# floats are decimal point numbers positive or negative
addFloat = 24.5 + 1004.005
subtractFloat = 546.90 - 132.56
multiplyFloat = 90.0 * 4.2
divideFloat = 36.6 / 6.6
moduloFloat = 17.0 % 3.0

# all operators work same on both floats or integers
