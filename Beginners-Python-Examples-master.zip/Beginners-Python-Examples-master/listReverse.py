getLi = [12,43,7,43,87,89,56,9809,9878,56,78,98,True,56,76]
reverseList = getLi[::-1] # [::-1] tells to step from end without difference
print(reverseList)
