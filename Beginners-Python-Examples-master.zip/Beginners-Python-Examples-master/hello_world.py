# printing hello world is a tradition in beginners 
# it is normally used to if check everything is okay
import sys

sys.stdout.write("Hello, ")
sys.stdout.write("World!")
sys.stdout.write("\n")
print("Hello, World!")
