import webbrowser
import time



make_use = 1

while make_use < 3 :
	time.sleep(10)
	webbrowser.open("https://www.youtube.com/results?search_query=comedy+pranks")
	make_use = make_use + 1
