
<pre> 
<i>'shell_games'</i> Sub-directory contains all the <strong>games(programs)</strong>
written for terminal/shell/command line.
More games like <i>sudoku, chess, battleship, et cetera</i> are on their way!
</pre>
The programs have been <strong>re-checked</strong> and <strong>re-mastered</strong> by me!<br>
Although i've tried to keep it as orignal as possible.<br>
Keep Patience It'll take time to go through every program!!<br>
<b>Thanks</b>

