# Beginners-Python-Programs
Basic python CLI programs as examples<br>
All the examples are useful examples<br>
This examples are of beginners level<br>
<br>
Hey guys I wrote these programs when I was just starting up with programming, now I realize that many of 'em feel very un-professional and useless so I decided to go one by one through all and make 'em more usefull and professional !
<br>

Note: In 2.x versions input isn't useful , lly , in 3.x versions raw_input isn't useful. Also, xrange() and other methods are discontinued or changed in 3.x versions of python. Change the keywords accordingly! 

<pre>
<strong>NOTE: WORK IN PROGRESS!
Files Outside Particular Folders/Directories have not been checked yet!
Files inside, directories offer much elegant code and explaination
</strong>
</pre>
<br><br>
Also see this : Beginners-Python-Examples/CONTRIBUTING.md<br>
contact kalpaktake@gmail.com
