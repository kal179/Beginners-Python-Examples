# Example of accessing elements in list

inside = list("abcdefghijklmnopqrs tuvwyxyz")
print (inside[10] + inside[0] + inside[11] + inside[15] + inside[0] + inside[10] + inside[19] + inside[20] + inside[0] + inside[10] + inside[4])
		
