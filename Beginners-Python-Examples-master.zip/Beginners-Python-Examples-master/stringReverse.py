# String Reverse
# This program is funny

getString = str(input('Word to Reverse : '))
reverseString = getString[::-1] # [::-1] tells to step from end without difference
print(reverseString)

	 